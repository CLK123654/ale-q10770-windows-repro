PRAGMA foreign_keys=ON;
PRAGMA trusted_schema=ON;
DROP TRIGGER IF EXISTS articles_ai;
DROP TRIGGER IF EXISTS articles_ad;
DROP TRIGGER IF EXISTS articles_au;
CREATE TRIGGER articles_ai AFTER INSERT ON articles BEGIN
  INSERT INTO article_fts(rowid,title,body) VALUES(new.article_id,new.title,new.body);
END;
CREATE TRIGGER articles_ad AFTER DELETE ON articles BEGIN
  INSERT INTO article_fts(article_fts,rowid,title,body) VALUES('delete',old.article_id,old.title,old.body);
END;
CREATE TRIGGER articles_au AFTER UPDATE OF title,body ON articles BEGIN
  INSERT INTO article_fts(article_fts,rowid,title,body) VALUES('delete',old.article_id,old.title,old.body);
  INSERT INTO article_fts(rowid,title,body) VALUES(new.article_id,new.title,new.body);
END;
INSERT INTO article_fts(article_fts) VALUES('rebuild');
INSERT INTO article_fts(article_fts) VALUES('optimize');
