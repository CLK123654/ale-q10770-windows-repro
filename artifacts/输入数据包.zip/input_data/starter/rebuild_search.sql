-- TODO: repair FTS5 external-content triggers and rebuild the index.
SELECT count(*) AS source_articles FROM articles;
