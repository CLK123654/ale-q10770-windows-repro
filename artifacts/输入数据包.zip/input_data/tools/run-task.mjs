import fs from 'node:fs/promises';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

const inputRoot=process.cwd();
const outputRoot=path.resolve(inputRoot,'..','output');
const program=path.join(outputRoot,'tools','audit_search.mjs');
const repair=path.join(outputRoot,'rebuild_help_search.sql');
const reports=path.join(outputRoot,'reports');
const repairedDb=path.join(outputRoot,'help_search_repaired.db');
const sqliteBin=process.env.ALE_SQLITE_BIN||'sqlite3';
const required=['query_rankings.csv','locale_fallback.csv','index_sync_audit.csv','reconciliation_summary.json'];
const assert=(value,message)=>{if(!value)throw new Error(message)};
async function clean(){await fs.rm(reports,{recursive:true,force:true});await fs.rm(repairedDb,{force:true})}
function sqlite(args,input){return spawnSync(sqliteBin,args,{input,encoding:'utf8',timeout:90000,windowsHide:true})}
function execute(){return spawnSync(process.execPath,[program],{cwd:inputRoot,encoding:'utf8',timeout:120000,windowsHide:true,env:{...process.env,ALE_SQLITE_BIN:sqliteBin}})}

try{
  assert(path.basename(inputRoot)==='input_data','请在input_data目录执行npm run process');
  await clean();
  const version=sqlite(['-version']);
  assert(version.status===0,`SQLite不可执行:${version.stderr||version.stdout}`);
  const fts=sqlite([path.join(inputRoot,'help_search.db'),"SELECT sqlite_compileoption_used('ENABLE_FTS5');"]);
  assert(fts.status===0&&fts.stdout.trim()==='1','SQLite未启用FTS5');
  const source=await fs.readFile(program,'utf8');
  const sql=await fs.readFile(repair,'utf8');
  assert(!source.includes('TODO')&&!sql.includes('TODO'),'业务实现仍含TODO');
  assert(source.includes('ALE_SQLITE_BIN')&&/spawnSync/u.test(source),'业务程序必须调用指定SQLite CLI');
  assert(/article_fts[\s\S]*MATCH/u.test(source)&&/bm25/u.test(source),'业务程序必须执行FTS5 MATCH和bm25');
  assert(/CREATE TRIGGER articles_ai/u.test(sql)&&/CREATE TRIGGER articles_ad/u.test(sql)&&/CREATE TRIGGER articles_au/u.test(sql),'三类同步触发器不完整');
  assert(/VALUES\('rebuild'\)/u.test(sql)&&/VALUES\('optimize'\)/u.test(sql),'缺少FTS5 rebuild或optimize');
  const cases=await fs.readFile(path.join(inputRoot,'data','query_cases.csv'),'utf8');
  for(const line of cases.trim().split(/\r?\n/u).slice(1)){const id=line.split(',')[0];assert(!source.includes(`'${id}'`)&&!source.includes(`"${id}"`),`业务程序不得按case_id硬编码:${id}`)}
  const result=execute();
  assert(result.status===0,`SQLite程序执行失败:${result.stdout}${result.stderr}`);
  for(const name of required){const stat=await fs.stat(path.join(reports,name));assert(stat.isFile()&&stat.size>0,`缺少报告:${name}`)}
  const reconciliation=JSON.parse(await fs.readFile(path.join(reports,'reconciliation_summary.json'),'utf8'));
  assert(reconciliation.result==='PASS'&&Object.values(reconciliation.relationships).every(Boolean),'搜索对账未闭合');
  const check=sqlite(['-json',repairedDb,"SELECT (SELECT integrity_check FROM pragma_integrity_check LIMIT 1) AS integrity_check,(SELECT count(*) FROM articles) AS article_count,(SELECT count(*) FROM sqlite_master WHERE type='trigger' AND name IN('articles_ai','articles_ad','articles_au')) AS trigger_count,(SELECT count(*) FROM article_fts WHERE article_fts MATCH 'passkey') AS passkey_count;"]);
  assert(check.status===0,`修复库不可查询:${check.stderr}`);
  const row=JSON.parse(check.stdout.trim())[0];
  assert(row.integrity_check==='ok'&&row.trigger_count===3&&row.passkey_count>0,'修复库边界错误');
  console.log(JSON.stringify({result:'PASS',sqlite_version:version.stdout.trim(),reports:4,article_count:row.article_count}));
}catch(error){await clean();console.error(error instanceof Error?error.message:String(error));process.exitCode=1}
